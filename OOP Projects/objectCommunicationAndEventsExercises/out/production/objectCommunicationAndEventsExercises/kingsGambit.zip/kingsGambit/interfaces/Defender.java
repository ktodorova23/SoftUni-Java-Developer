package kingsGambit.interfaces;

public interface Defender {
    String respondToAttack();
}
