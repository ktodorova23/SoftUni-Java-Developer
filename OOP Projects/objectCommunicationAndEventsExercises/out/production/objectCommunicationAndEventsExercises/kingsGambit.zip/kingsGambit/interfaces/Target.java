package kingsGambit.interfaces;

public interface Target {
    void uponAttack();

    void killDefender(String cmdArg);
}
