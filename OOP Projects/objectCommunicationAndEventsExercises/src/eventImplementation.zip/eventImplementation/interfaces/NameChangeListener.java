package eventImplementation.interfaces;

import eventImplementation.Event;

public interface NameChangeListener {
    void handleChangedName(Event event);
}
