package dependencyInversion.interfaces;

public interface Strategy {
    int calculateResult(int first, int second);
}
