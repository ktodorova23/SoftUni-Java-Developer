package interfaces;

public interface Nation {
    double calculateTotalPower();

    double getBonusFromMonuments();

    void addBender(Bender bender);

    void addMonument(Monument monument);

    double getPower();

    void emptyArmy();
}
