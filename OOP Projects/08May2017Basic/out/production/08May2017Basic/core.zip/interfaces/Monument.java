package interfaces;

public interface Monument {
    String getName();

    int getAffinity();
}
