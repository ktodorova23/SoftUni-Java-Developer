package interfaces;

public interface Bender {
    String getName();

    int getPower();

    double getTotalPower();
}
