package entities.monuments;

import interfaces.Monument;

public abstract class MonumentImpl implements Monument {
    private String name;
    private int affinity;

    protected MonumentImpl(String name, int affinity) {
        this.name = name;
        this.affinity = affinity;
    }

    public String getName() {
        return this.name;
    }

    @Override
    public int getAffinity() {
        return this.affinity;
    }


}
