package core;

import containers.WarStatistics;
import entities.nations.AirNation;
import entities.nations.EarthNation;
import entities.nations.FireNation;
import entities.nations.WaterNation;
import factories.BenderFactory;
import factories.MonumentFactory;
import interfaces.*;
import io.InputReaderImpl;
import io.OutputWriterImpl;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class Engine {
    private InputReader reader;
    private OutputWriter writer;

    public Engine() {
        this.reader = new InputReaderImpl();
        this.writer = new OutputWriterImpl();
    }

    public void run() throws IOException {
        String line;

        AirNation airNation = null;
        EarthNation earthNation = null;
        FireNation fireNation = null;
        WaterNation waterNation = null;

        List<Nation> nations = new ArrayList<>();
        nations.add(airNation);
        nations.add(earthNation);
        nations.add(fireNation);
        nations.add(waterNation);

        WarStatistics war = new WarStatistics();

        while (!"Quit".equals(line = this.reader.readLine())) {
            String[] arguments = line.split("\\s+");

            switch (arguments[0]) {
                case "Bender":
                    Bender bender = BenderFactory.createBender(arguments[1], arguments[2], Integer.parseInt(arguments[3]), Double.parseDouble(arguments
                            [4]));
                    if (arguments[1].equals("Fire")) {
                        if (nations.get(2) == null) {
                            nations.set(2, new FireNation());
                        }
                        nations.get(2).addBender(bender);
                    } else if (arguments[1].equals("Air")) {
                        if (nations.get(0) == null) {
                            nations.set(0, new AirNation());
                        }
                        nations.get(0).addBender(bender);
                    } else if (arguments[1].equals("Water")) {
                        if (nations.get(3) == null) {
                            nations.set(3, new WaterNation());
                        }
                        nations.get(3).addBender(bender);
                    } else {
                        if (nations.get(1) == null) {
                            nations.set(1, new EarthNation());
                        }
                        nations.get(1).addBender(bender);
                    }
                    break;
                case "Monument":
                    Monument monument = MonumentFactory.createMonument(arguments[1], arguments[2], Integer.parseInt(arguments[3]));
                    if (arguments[1].equals("Fire")) {
                        if (nations.get(2) == null) {
                            nations.set(2, new FireNation());
                    }
                        nations.get(2).addMonument(monument);
                    } else if (arguments[1].equals("Air")) {
                        if (nations.get(0) == null) {
                            nations.set(0, new AirNation());
                        }
                        nations.get(0).addMonument(monument);
                    } else if (arguments[1].equals("Water")) {
                        if (nations.get(3) == null) {
                            nations.set(3, new WaterNation());
                        }
                        nations.get(3).addMonument(monument);
                    } else {
                        if (nations.get(1) == null) {
                            nations.set(1, new EarthNation());
                        }
                        nations.get(1).addMonument(monument);
                    }
                    break;
                case "Status":
                    if (arguments[1].equals("Fire")) {
                        this.writer.write(nations.get(2).toString());
                    } else if (arguments[1].equals("Air")) {
                        this.writer.write(nations.get(0).toString());
                    } else if (arguments[1].equals("Water")) {
                        this.writer.write(nations.get(3).toString());
                    } else {
                        this.writer.write(nations.get(1).toString());
                    }
                    break;
                case "War":
                    war.addWarInfo(arguments[1]);

                    List<Nation> list = nations.stream().filter(nation -> nation != null).collect(Collectors.toList());

                    Nation nation = list.get(0);
                    for (Nation entry : list) {
                        if (nation.getPower() > entry.getPower()) {
                            entry.emptyArmy();
                        } else {
                            nation.emptyArmy();
                            nation = entry;
                        }
                    }
                    break;
            }
        }

        this.writer.write(war.toString());
    }
}
