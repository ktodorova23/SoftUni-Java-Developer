import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Comparator;
import java.util.TreeSet;

public class Main {

    public static void main(String[] args) throws NoSuchMethodException, IllegalAccessException, InvocationTargetException, InstantiationException {
        Class clazz = Reflection.class;
//        System.out.println(clazz);
//        System.out.println(clazz.getSuperclass());
//
//        Class[] interfaces = clazz.getInterfaces();
//
//        for (Class anInterface : interfaces) {
//            System.out.println(anInterface);
//        }
//
//        Constructor constructor = clazz.getConstructor();
//
//        Reflection reflection = (Reflection) constructor.newInstance();
//        System.out.println(reflection);

        TreeSet<Method> getters = new TreeSet<>(Comparator.comparing(Method::getName));
        TreeSet<Method> setters = new TreeSet<>(Comparator.comparing(Method::getName));

        Method[] methods = clazz.getDeclaredMethods();

        for (Method method : methods) {
            if (method.getName().startsWith("get")) {
                if (method.getParameterCount() == 0) {
                    getters.add(method);
                }
            }
            if (method.getName().startsWith("set")) {
                if (method.getParameterCount() == 1) {
                    if (void.class.equals(method.getReturnType())) {
                        setters.add(method);
                    }
                }
            }
        }

        getters.forEach
                (method -> System.out.println(String.format("%s will return %s",
                        method.getName(),
                        method.getReturnType())));

        setters.forEach
                (method -> System.out.println(String.format("%s and will set field of %s",
                        method.getName(),
                        method.getParameterTypes()[0])));
    }
}
