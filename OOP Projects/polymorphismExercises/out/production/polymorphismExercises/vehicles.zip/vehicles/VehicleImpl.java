package vehicles;

import java.text.DecimalFormat;

public abstract class VehicleImpl implements Vehicle {
    private double fuelQuantity;
    private double fuelConsumption;

    public VehicleImpl(double fuelQuantity, double fuelConsumption) {
        this.fuelQuantity = fuelQuantity;
        this.setFuelConsuption(fuelConsumption);
    }

    protected void setFuelConsuption(double fuelConsumption) {
        this.fuelConsumption = fuelConsumption;
    }

    @Override
    public String drive(double distance) {
        String result = "";
        DecimalFormat df = new DecimalFormat("#.##");

        if (distance * this.fuelConsumption <= this.fuelQuantity) {
            result = String.format("travelled %s km", df.format(distance));
            this.fuelQuantity -= distance * this.fuelConsumption;
        } else {
            result = "needs refueling";
        }
        return result;
    }

    @Override
    public void refuel(double liters) {
        this.fuelQuantity += liters;
    }

    @Override
    public String toString() {
        return String.format("%s: %.2f", this.getClass().getSimpleName(), this.fuelQuantity);
    }
}
