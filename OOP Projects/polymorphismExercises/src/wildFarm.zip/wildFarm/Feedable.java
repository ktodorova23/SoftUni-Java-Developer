package wildFarm;

public interface Feedable {
    void eatFood(Food food);
}
