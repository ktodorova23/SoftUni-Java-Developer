package wildFarm;

public abstract class Felime extends Mammal {
    public Felime(String name, Double weight, String livingRegion) {
        super(name, weight, livingRegion);
    }
}
