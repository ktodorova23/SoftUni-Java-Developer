package wildFarm;

public interface SoundProducable {
    String makeSound();
}
