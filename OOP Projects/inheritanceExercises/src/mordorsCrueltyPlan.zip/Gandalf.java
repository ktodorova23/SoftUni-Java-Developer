import java.util.Arrays;
import java.util.List;

public class Gandalf {
    private int foodPoints;

    public Gandalf() {
        this.foodPoints = 0;
    }

    public void eatFood(String food) {
        if (food.equalsIgnoreCase("cram")) {
            this.foodPoints += 2;
        } else if (food.equalsIgnoreCase("lembas")) {
            this.foodPoints += 3;
        } else if (food.equalsIgnoreCase("apple")) {
            this.foodPoints += 1;
        } else if (food.equalsIgnoreCase("melon")) {
            this.foodPoints += 1;
        } else if (food.equalsIgnoreCase("honeycake")) {
            this.foodPoints += 5;
        } else if (food.equalsIgnoreCase("mushrooms")) {
            this.foodPoints -= 10;
        } else {
            this.foodPoints -= 1;
        }
    }

    public int getFoodPoints() {
        return foodPoints;
    }

    public String getMood() {
        String mood = "";
        if (this.getFoodPoints() < -5) {
            mood = "Angry";
        } else if (this.getFoodPoints() < 0) {
            mood = "Sad";
        } else if (this.getFoodPoints() <= 15) {
            mood = "Happy";
        } else {
            mood = "JavaScript";
        }
        return mood;
    }
}
