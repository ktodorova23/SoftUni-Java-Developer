import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {

            try {
                BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

                String[] studentInformation = reader.readLine().split("\\s+");
                String[] workerInformation = reader.readLine().split("\\s+");

                Student student = new Student(studentInformation[0], studentInformation[1], studentInformation[2]);
                Worker worker = new Worker(workerInformation[0], workerInformation[1],
                        Double.parseDouble(workerInformation[2]), Double.parseDouble(workerInformation[3]));

                System.out.println(student.toString());
                System.out.println(worker.toString());
            } catch (IllegalArgumentException error) {
                System.out.println(error.getMessage());
            }


    }
}
