import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {


        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        List<Animal> animals = new ArrayList<>();

        String line;

        while (!"Beast!".equals(line = reader.readLine())) {
            String[] animalData = reader.readLine().split("\\s+");
            try {
                if (line.equals("Cat")) {
                    Cat cat = new Cat(animalData[0], Integer.parseInt(animalData[1]), animalData[2]);
                    animals.add(cat);
                } else if (line.equals("Dog")) {
                    Dog dog = new Dog(animalData[0], Integer.parseInt(animalData[1]), animalData[2]);
                    animals.add(dog);
                } else if (line.equals("Frog")) {
                    Frog frog = new Frog(animalData[0], Integer.parseInt(animalData[1]), animalData[2]);
                    animals.add(frog);
                }else if (line.equals("Kitten")) {
                    Kitten kitten = new Kitten(animalData[0], Integer.parseInt(animalData[1]), animalData[2]);
                    animals.add(kitten);
                } else {
                    Tomcat tomcat = new Tomcat(animalData[0], Integer.parseInt(animalData[1]), animalData[2]);
                    animals.add(tomcat);
                }
            } catch (IllegalArgumentException error) {
                System.out.println(error.getMessage());
            }
        }

        for (Animal animal : animals) {
            System.out.println(animal.toString());
        }
    }
}
