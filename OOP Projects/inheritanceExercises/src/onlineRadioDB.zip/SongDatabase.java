import java.util.ArrayList;
import java.util.List;

public class SongDatabase {
    private List<Song> songs;

    public SongDatabase() {
        this.songs = new ArrayList<>();
    }

    public void addSong(Song song) {
        this.songs.add(song);
    }

    public int getDatabaseLength() {
        return this.songs.size();
    }

    public String getTotalLengthOfSongs() {
        StringBuilder length = new StringBuilder();

        int totalTime = 0;
        for (Song song : songs) {
            int minutes = Integer.parseInt(song.getLength().split(":")[0]);
            int seconds = Integer.parseInt(song.getLength().split(":")[1]);
            totalTime += minutes * 60 + seconds;
        }
        int hours = totalTime / 3600;
        int minutes = (totalTime / 60) % 60;
        int seconds = totalTime % 60;

        length.append(hours).append("h ");
        length.append(minutes).append("m ");
        length.append(seconds).append("s");
        return length.toString();
    }
}
