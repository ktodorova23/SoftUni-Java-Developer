import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {


        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int countSongs = Integer.parseInt(reader.readLine());

        SongDatabase songDatabase = new SongDatabase();
        while (countSongs-- > 0) {
            String[] songData = reader.readLine().split(";");

            try {
                Song song = new Song(songData[0], songData[1], songData[2]);
                songDatabase.addSong(song);
                System.out.println("Song added.");
            } catch (IllegalArgumentException error) {
                System.out.println(error.getMessage());
            }
        }

        System.out.println("Songs added: " + songDatabase.getDatabaseLength());
        System.out.println("Playlist length: " + songDatabase.getTotalLengthOfSongs());
    }
}
