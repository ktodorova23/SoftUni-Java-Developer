package models.clusters;

import models.cells.Cell;

import java.util.Map;
import java.util.TreeMap;

public class Cluster {
    private String id;
    private int rows;
    private int cols;
    private Map<String, Cell> cells;

    public Cluster(String id, int rows, int cols) {
        this.id = id;
        this.rows = rows;
        this.cols = cols;
        this.cells = new TreeMap<>();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
