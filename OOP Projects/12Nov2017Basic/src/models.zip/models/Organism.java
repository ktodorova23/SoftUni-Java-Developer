package models;

import models.clusters.Cluster;

import java.util.Map;
import java.util.TreeMap;

public class Organism {
    private String name;
    private Map<String, Cluster> clusters;

    public Organism(String name) {
        this.name = name;
        this.clusters = new TreeMap<String, Cluster>();
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
