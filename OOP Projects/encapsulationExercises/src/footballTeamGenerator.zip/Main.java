import com.sun.source.tree.CatchTree;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.HashMap;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        HashMap<String, Team> teams = new HashMap<>();

        String line;

        while (!"END".equals(line = reader.readLine())) {
            String[] tokens = line.split(";");
            switch (tokens[0]) {
                case "Team":
                    try {
                        Team team = new Team(tokens[1]);
                        teams.putIfAbsent(tokens[1], team);
                    } catch (IllegalArgumentException exception) {
                        System.out.println(exception.getMessage());
                    }
                    break;
                case "Add":
                    if (teams.containsKey(tokens[1])) {
                        try {
                            Player player = new Player(tokens[2], Integer.parseInt(tokens[3]), Integer.parseInt(tokens[4]),
                                    Integer.parseInt(tokens[5]), Integer.parseInt(tokens[6]), Integer.parseInt(tokens[7]));
                            teams.get(tokens[1]).addPlayer(player);
                        } catch (IllegalArgumentException ex) {
                            System.out.println(ex.getMessage());
                        }
                    } else {
                        System.out.println(String.format("Team %s does not exist.", tokens[1]));
                    }
                    break;
                case "Remove":
                    try {
                        teams.get(tokens[1]).removePlayer(tokens[2]);
                    } catch (IllegalArgumentException ex) {
                        System.out.println(ex.getMessage());
                    }
                    break;
                case "Rating":
                    if (teams.containsKey(tokens[1])) {
                        System.out.println(String.format("%s - %d", tokens[1], Math.round(teams.get(tokens[1]).getRating())));
                    } else {
                        System.out.println(String.format("Team %s does not exist.", tokens[1]));
                    }
                    break;
            }
        }
    }
}
