import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.LinkedHashMap;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] peopleInputs = reader.readLine().split(";");
        String[] productsInputs = reader.readLine().split(";");

        LinkedHashMap<String, Person> people = new LinkedHashMap();
        LinkedHashMap<String, Product> products = new LinkedHashMap();

        for (String personData : peopleInputs) {
            String[] data = personData.split("=");
            try {
                Person person = new Person(data[0], Double.parseDouble(data[1]));
                people.putIfAbsent(person.getName(), person);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        for (String productsData : productsInputs) {
            String[] data = productsData.split("=");
            try {
                Product product = new Product(data[0], Double.parseDouble(data[1]));
                products.putIfAbsent(data[0], product);
            } catch (Exception e) {
                System.out.println(e.getMessage());
            }
        }

        if (!people.isEmpty()) {
            String line;

            while (!"END".equals(line = reader.readLine())) {
                String[] tokens = line.split("\\s+");

                try {
                    people.get(tokens[0]).buyProduct(products.get(tokens[1]));
                    System.out.println(String.format("%s bought %s", tokens[0], tokens[1]));
                } catch (Exception e) {
                    System.out.println(e.getMessage());
                }
            }

            people.entrySet().stream().forEach(p -> {
                        StringBuilder sb = new StringBuilder();
                        sb.append(p.getKey()).append(" - ");
                        if (p.getValue().getProducts().size() > 0) {
                            p.getValue().getProducts().forEach(product -> sb.append(product.getName()).append(", "));
                            sb.delete(sb.length() - 2, sb.length());
                        } else {
                            sb.append("Nothing bought");
                        }
                        System.out.println(sb);
                    }
            );
        }
    }
}
