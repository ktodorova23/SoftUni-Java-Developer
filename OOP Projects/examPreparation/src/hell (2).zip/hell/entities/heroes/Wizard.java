package hell.entities.heroes;

public class Wizard extends HeroImpl {
    public Wizard(String name) {
        super(name, 25, 25, 100, 100, 250);
    }
}
