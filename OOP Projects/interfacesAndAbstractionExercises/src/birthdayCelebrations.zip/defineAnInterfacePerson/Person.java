package defineAnInterfacePerson;

public interface Person {
    public String getName();
    public int getAge();
}
