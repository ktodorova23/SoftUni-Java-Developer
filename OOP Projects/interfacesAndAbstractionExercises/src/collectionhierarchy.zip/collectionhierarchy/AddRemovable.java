package collectionhierarchy;

public interface AddRemovable extends Addable {
    public String remove();
}
