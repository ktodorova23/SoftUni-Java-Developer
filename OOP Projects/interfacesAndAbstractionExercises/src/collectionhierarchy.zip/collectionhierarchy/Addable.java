package collectionhierarchy;

public interface Addable {
    public int add(String item);
}
