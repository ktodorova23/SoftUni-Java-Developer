package collectionhierarchy;

public interface MyList extends AddRemovable {
    public int getUsed();
}
