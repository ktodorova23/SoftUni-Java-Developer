package militaryElite.interfaces;

public interface LeutenantGeneral extends Private {
    public void addPrivate(Private soldier);
}
