package militaryElite.interfaces;

import militaryElite.general.Repair;

public interface Engineer extends Private {
    public void addRepair(Repair repair);
}
