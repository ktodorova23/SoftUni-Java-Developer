package militaryElite.interfaces;

public interface Soldier {
    public int getId();
}
