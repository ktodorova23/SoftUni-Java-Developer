package militaryElite.interfaces;

public interface SpecialisedSoldier extends Private {
}
