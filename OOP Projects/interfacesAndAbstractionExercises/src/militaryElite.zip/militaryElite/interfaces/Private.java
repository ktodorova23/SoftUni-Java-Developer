package militaryElite.interfaces;

public interface Private extends Soldier{
    int getId();
}
