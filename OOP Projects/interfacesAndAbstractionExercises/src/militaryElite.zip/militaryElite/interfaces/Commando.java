package militaryElite.interfaces;

import militaryElite.general.Mission;

public interface Commando extends Private {
    void addMission(Mission mission);
}
