package militaryElite.enumerations;

public enum State {
    inProgress,
    Finished,
}
