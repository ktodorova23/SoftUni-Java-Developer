package militaryElite.enumerations;

public enum Corp {
    Airforces,
    Marines,
}
