package defineAnInterfacePerson;

public interface Identifiable {
    public String getId();
}
