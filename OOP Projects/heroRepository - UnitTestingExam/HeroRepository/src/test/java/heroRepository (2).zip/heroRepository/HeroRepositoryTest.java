package heroRepository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HeroRepositoryTest {
    private HeroRepository repository;
    private Hero hero;
    private Item item;

    @Before
    public void setRepository() {
        this.repository = new HeroRepository();
        item = new Item(5, 5, 5);
        hero = new Hero("Pesho", 3, item);
    }

    @Test(expected = IllegalArgumentException.class)
    public void addShouldThrowAnExceptionIfDuplicateIsAdded() {
        this.repository.add(hero);
        this.repository.add(hero);
    }

    @Test
    public void addShouldIncreaseTheSizeOfTheRepository() {
        this.repository.add(hero);
        Assert.assertEquals(1, this.repository.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void removeShouldThrowAnExceptionIfListIsEmpty() {
        this.repository.remove("Ivan");
    }

    @Test(expected = NullPointerException.class)
    public void removeShouldThrowAnExceptionIfHeroIsNotPresent() {
        this.repository.add(hero);
        this.repository.remove("Ivan");
    }

    @Test
    public void removeShouldReduceTheSizeOfTheRepositoryWhenSuccessful(){
        this.repository.add(hero);
        this.repository.remove("Pesho");
        Assert.assertEquals(0, this.repository.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestStrengthShouldThrowAnExceptionIfListIsEmpty() {
        this.repository.getHeroWithHighestStrength();
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestStrengthShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        Item item2 = new Item(-1, 2, 2);
        Hero hero2 = new Hero("Ivan", 2, item2);
        this.repository.getHeroWithHighestStrength();
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestIntelligenceShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        Item item2 = new Item(15, 2, -2);
        Hero hero2 = new Hero("Ivan", 2, item2);
        this.repository.getHeroWithHighestIntelligence();
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestAgilityShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        Item item2 = new Item(10, -2, 2);
        Hero hero2 = new Hero("Ivan", 2, item2);
        this.repository.getHeroWithHighestAgility();
    }

    @Test
    public void getHeroWithHighestStrengthShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestStrength());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestAgilityShouldThrowAnExceptionIfListIsEmpty() {
        this.repository.getHeroWithHighestAgility();
    }

    @Test
    public void getHeroWithHighestAgilityShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestAgility());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestIntelligenceShouldThrowAnExceptionIfListIsEmpty() {
        this.repository.getHeroWithHighestIntelligence();
    }

    @Test
    public void getHeroWithHighestIntelligenceShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestIntelligence());
    }
}