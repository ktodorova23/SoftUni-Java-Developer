package heroRepository;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class HeroRepositoryTest {
    private HeroRepository repository;
    private Hero hero;
    private Item item;

    @Before
    public void setRepository() {
        this.repository = new HeroRepository();
        item = new Item(5, 5, 5);
        hero = new Hero("Pesho", 3, item);
    }

    @Test
    public void getCountShouldReturnCorrectValue() {
        this.repository.add(hero);
        Assert.assertEquals(1, this.repository.getCount());
    }

    @Test(expected = IllegalArgumentException.class)
    public void addShouldThrowAnExceptionIfDuplicateIsAdded() {

        this.repository.add(hero);
        this.repository.add(hero);
    }

    @Test
    public void addShouldIncreaseTheSizeOfTheRepository() {
        this.repository.add(hero);
        Assert.assertEquals(1, this.repository.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void removeShouldThrowAnExceptionIfHeroIsNotPresent() {
        this.repository.remove("Ivan");
    }

    @Test
    public void removeShouldReduceTheSizeOfTheRepositoryWhenSuccessful(){
        this.repository.add(hero);
        this.repository.remove("Pesho");
        Assert.assertEquals(0, this.repository.getCount());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestStrengthShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        this.repository.getHeroWithHighestStrength();
    }

    @Test
    public void getHeroWithHighestStrengthShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestStrength());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestAgilityShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        this.repository.getHeroWithHighestAgility();
    }

    @Test
    public void getHeroWithHighestAgilityShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestAgility());
    }

    @Test(expected = NullPointerException.class)
    public void getHeroWithHighestIntelligenceShouldThrowAnExceptionIfNoSuchHeroIsFound() {
        this.repository.getHeroWithHighestIntelligence();
    }

    @Test
    public void getHeroWithHighestIntelligenceShouldReturnHeroCorectly() {
        this.repository.add(hero);
        Assert.assertEquals(hero, this.repository.getHeroWithHighestIntelligence());
    }

}