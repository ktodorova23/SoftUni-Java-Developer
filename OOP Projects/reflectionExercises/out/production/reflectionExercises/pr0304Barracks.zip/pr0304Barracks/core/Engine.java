package pr0304Barracks.core;

import jdk.jshell.spi.ExecutionControl;
import pr0304Barracks.contracts.*;
import pr0304Barracks.contracts.Runnable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class Engine implements Runnable {
	private static final String COMMANDS_PACKAGE = "pr0304Barracks.core.commands.";

	private Repository repository;
	private UnitFactory unitFactory;

	public Engine(Repository repository, UnitFactory unitFactory) {
		this.repository = repository;
		this.unitFactory = unitFactory;
	}

	@Override
	public void run() {
		BufferedReader reader = new BufferedReader(
				new InputStreamReader(System.in));
		while (true) {
			try {
				String input = reader.readLine();
				String[] data = input.split("\\s+");
				String commandName = data[0];
				String result = interpretCommand(data);
				if (result.equals("fight")) {
					break;
				}
				System.out.println(result);
			} catch (RuntimeException e) {
				System.out.println(e.getMessage());
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private String interpretCommand(String[] data) {
		String result = "";
		String commandName = Character.toUpperCase(data[0].charAt(0)) + data[0].substring(1) + "Command";

		try {
			Class<? extends Executable> commandClass =
					(Class<? extends Executable>) Class.forName(Engine.COMMANDS_PACKAGE + commandName);

			Constructor<? extends Executable> constructor =
					commandClass.getDeclaredConstructor(String[].class, Repository.class, UnitFactory.class);
			constructor.setAccessible(true);
			Executable executable = constructor.newInstance(data, this.repository, this.unitFactory);
			result = executable.execute();
		} catch (ClassNotFoundException | NoSuchMethodException | InstantiationException | IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
		}
		return result;
	}
}
