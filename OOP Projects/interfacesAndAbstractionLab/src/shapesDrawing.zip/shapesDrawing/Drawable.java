package shapesDrawing;

public interface Drawable {
    public void draw();
}
