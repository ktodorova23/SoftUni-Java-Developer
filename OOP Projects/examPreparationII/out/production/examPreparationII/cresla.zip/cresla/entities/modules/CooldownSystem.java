package cresla.entities.modules;

public class CooldownSystem extends BaseAbsorbingModule {
    public CooldownSystem(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
