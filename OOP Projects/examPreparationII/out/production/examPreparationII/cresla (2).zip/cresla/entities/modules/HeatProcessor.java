package cresla.entities.modules;

public class HeatProcessor extends BaseAbsorbingModule {
    protected HeatProcessor(int id, int heatAbsorbing) {
        super(id, heatAbsorbing);
    }
}
