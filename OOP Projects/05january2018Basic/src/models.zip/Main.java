import models.*;

public class Main {

    public static void main(String[] args) {
        Colony colony = new Colony(15, 20);

        Family family = new Family("TheSimpsons");

        Colonist surgeon = new Surgeon("Pesho", "TheSimpsons", 5, 28, "butcher");
        Colonist soldier = new Soldier("Pesho", "TheSimpsons", 5, 28);
        Colonist generalPractitioner = new GeneralPractitioner("Pesho", "TheSimpsons", 5, 28, "careless");
        Colonist softwareEngineer = new SoftwareEngineer("Pesho", "TheSimpsons", 5, 28);
        Colonist hardwareEngineer = new HardwareEngineer("Pesho", "TheSimpsons", 5, 28);

        System.out.println();
    }
}
