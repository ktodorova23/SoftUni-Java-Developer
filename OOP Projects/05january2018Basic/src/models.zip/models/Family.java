package models;

import java.util.*;

public class Family {
    private String id;
    private Map<String, Colonist> colonists;

    public Family(String id) {
        this.id = id;
        this.colonists = new TreeMap<>();
    }

    public String getId() {
        return this.id;
    }

    private void setId(String id) {
        this.id = id;
    }

    public List<Colonist> getColonists() {
        return List.copyOf(this.colonists.values());
    }
}
