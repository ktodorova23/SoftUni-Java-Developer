package models;

public abstract class Colonist {
    private String id;
    private String familyId;
    private int talent;
    private int age;
    private int potential;

    public Colonist(String id, String familyId, int talent, int age) {
        this.id = id;
        this.familyId = familyId;
        this.talent = talent;
        this.age = age;
    }

    public String getId() {
        return this.id;
    }

    private void setId(String id) {
        this.id = id;
    }

    public String getFamilyId() {
        return this.familyId;
    }

    private void setFamilyId(String familyId) {
        this.familyId = familyId;
    }

    public int getTalent() {
        return this.talent;
    }

    private void setTalent(int talent) {
        this.talent = talent;
    }

    public int getAge() {
        return this.age;
    }

    private void setAge(int age) {
        this.age = age;
    }

    public int getPotential() {
        return this.talent + this.getPotentialBonuses();
    }

    protected abstract int getPotentialBonuses();
}
