package models;

public abstract class Medic extends Colonist {
    private String sign;

    protected Medic(String id, String familyId, int talent, int age, String sign) {
        super(id, familyId, talent, age);
    }

    public String getSign() {
        return this.sign;
    }

    @Override
    protected int getPotentialBonuses() {
        return 2;
    }
}
