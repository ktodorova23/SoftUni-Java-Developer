import java.math.BigInteger;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        Scanner console = new Scanner(System.in);

        String[] input = console.nextLine().split(", ");

        String title = input[0];
        String content = input[1];
        String author = input[2];

        Article article = new Article(title, content, author);

        int num = Integer.parseInt(console.nextLine());

        for (int i = 0; i < num; i++) {
            String[] tokens = console.nextLine().split(": ");

            String cmd = tokens[0];
            switch (cmd) {
                case "Edit":
                    String newContent = tokens[1];
                    article.edit(newContent);
                    break;
                case "ChangeAuthor":
                    String newAuthor = tokens[1];
                    article.changeAuthor(newAuthor);
                    break;
                case "Rename":
                    String newTitle = tokens[1];
                    article.rename(newTitle);
                    break;
            }
        }

        System.out.println(article);
    }
}
