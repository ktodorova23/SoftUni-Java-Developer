package genericBox.tuple;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        String[] firstInput = reader.readLine().split("\\s+");
        String[] secondInput = reader.readLine().split("\\s+");
        String[] thirdInput = reader.readLine().split("\\s+");

        Tuple<String, String> firstPair = new Tuple<>(
                (firstInput[0] + " " + firstInput[1]),
                firstInput[2]
        );

        Tuple<String, Integer> secondPair = new Tuple<>(
                secondInput[0],
                Integer.parseInt(secondInput[1])
        );

        Tuple<Integer, Double> thirdPair = new Tuple<>(
                Integer.parseInt(thirdInput[0]),
                Double.parseDouble(thirdInput[1])
        );

        System.out.println(firstPair);
        System.out.println(secondPair);
        System.out.println(thirdPair);
    }
}
