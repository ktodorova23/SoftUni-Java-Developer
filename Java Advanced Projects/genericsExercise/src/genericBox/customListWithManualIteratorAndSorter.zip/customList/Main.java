package genericBox.customList;

public class Main {
    public static final Engine ENGINE = new Engine();
    public static void main(String[] args) {
        ENGINE.run();
    }
}
