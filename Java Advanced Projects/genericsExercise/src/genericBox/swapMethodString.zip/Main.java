package genericBox;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) throws IOException {
        BufferedReader reader = new BufferedReader(new InputStreamReader(System.in));

        int rows = Integer.parseInt(reader.readLine());

        List<Box<String>> listOfBoxes = new ArrayList<>();

        while (rows-- > 0) {
            String line = reader.readLine();
            Box box = new Box(line);

            listOfBoxes.add(box);
        }
        int[] indexes = Arrays.stream(reader.readLine().split("\\s+"))
                .mapToInt(Integer::parseInt)
                .toArray();
        swapElements(listOfBoxes, indexes[0], indexes[1]);

        for (Box<String> box : listOfBoxes) {
            System.out.println(box.toString());
        }
    }

    private static <T> List<Box<T>> swapElements(List<Box<T>> listOfBoxes, int firstIndex, int secondIndex) {
        Box temp = listOfBoxes.get(firstIndex);
        listOfBoxes.set(firstIndex, listOfBoxes.get(secondIndex));
        listOfBoxes.set(secondIndex, temp);

        return listOfBoxes;
    }

}
