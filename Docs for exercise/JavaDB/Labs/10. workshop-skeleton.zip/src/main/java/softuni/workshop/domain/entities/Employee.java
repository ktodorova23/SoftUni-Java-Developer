package softuni.workshop.domain.entities;

public class Employee {
    //TODO
}
