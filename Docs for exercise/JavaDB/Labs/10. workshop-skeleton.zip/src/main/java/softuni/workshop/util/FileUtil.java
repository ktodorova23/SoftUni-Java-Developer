package softuni.workshop.util;

import java.io.IOException;

public interface FileUtil {

    //TODO
}
