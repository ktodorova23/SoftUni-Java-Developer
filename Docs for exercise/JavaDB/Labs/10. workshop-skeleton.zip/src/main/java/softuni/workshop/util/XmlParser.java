package softuni.workshop.util;

public interface XmlParser {

}
