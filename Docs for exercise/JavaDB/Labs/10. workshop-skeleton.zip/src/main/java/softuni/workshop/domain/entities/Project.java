package softuni.workshop.domain.entities;

public class Project {
   //TODO
}
