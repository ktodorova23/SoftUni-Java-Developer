package softuni.workshop.util;

public interface ValidatorUtil {

}
