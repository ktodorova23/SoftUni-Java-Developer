package softuni.workshop.repository;

public interface EmployeeRepository  {

}
