package softuni.workshop.domain.entities;

public class Company{
    //TODO
}
