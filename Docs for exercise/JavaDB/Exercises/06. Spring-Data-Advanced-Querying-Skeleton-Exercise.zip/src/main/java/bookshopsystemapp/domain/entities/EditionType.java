package bookshopsystemapp.domain.entities;

public enum EditionType {

    NORMAL, PROMO, GOLD;
}
