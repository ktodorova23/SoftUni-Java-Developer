package softuni.workshop.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.workshop.repository.CompanyRepository;
import softuni.workshop.util.FileUtil;

import javax.xml.bind.JAXBException;
import java.io.*;

@Service
public class CompanyServiceImpl implements CompanyService {

    private final CompanyRepository companyRepository;

    @Autowired
    public CompanyServiceImpl(CompanyRepository companyRepository) {
        this.companyRepository = companyRepository;
    }

    @Override
    public void importCompanies() throws JAXBException {
        //TODO
    }

    @Override
    public boolean areImported() {
       return this.companyRepository.count() > 0;
    }

    @Override
    public String readCompaniesXmlFile() throws IOException {
        //TODO READ FILE
        return "";
    }


    @Override
    public void exportJsonCompanies() throws IOException {
        //TODO
    }

    @Override
    public String readCompaniesJsonFile() throws IOException {
        //TODO READ FILE
        return "";
    }

    @Override
    public boolean areExported() throws IOException {
       return false;
    }
}
