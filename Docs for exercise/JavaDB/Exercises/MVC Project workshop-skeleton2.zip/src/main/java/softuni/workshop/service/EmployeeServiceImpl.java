package softuni.workshop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.workshop.repository.EmployeeRepository;
import softuni.workshop.util.FileUtil;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBException;
import java.io.IOException;

@Service
@Transactional
public class EmployeeServiceImpl implements EmployeeService {


    private final EmployeeRepository employeeRepository;

    @Autowired
    public EmployeeServiceImpl(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @Override
    public void importEmployees() throws JAXBException {
        //TODO
    }


    @Override
    public boolean areImported() {
        return this.employeeRepository.count() > 0;
    }

    @Override
    public String readEmployeesXmlFile() throws IOException {
        //TODO READ FILE
        return "";
    }

    @Override
    public String exportEmployeesWithAgeAbove() {
        //TODO
        return  "";
    }

    @Override
    public void exportEmployees() throws JAXBException {
        //TODO
    }


    @Override
    public void exportEmployeesToJson() throws IOException {
        //TODO
    }

    @Override
    public String readEmployeesJsonFile() throws IOException {
        //TODO READ FILE
        return "";
    }

    @Override
    public boolean areExported() throws IOException {
       return  false;
    }

    @Override
    public String exportEmployeesWithGivenName() {
        //TODO
        return  "";
    }

    @Override
    public String exportEmployeesWithGivenProjectName() {
        //TODO
        return  "";
    }
}
