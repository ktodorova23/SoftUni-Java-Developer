package softuni.workshop.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import softuni.workshop.repository.ProjectRepository;
import softuni.workshop.util.FileUtil;

import javax.transaction.Transactional;
import javax.xml.bind.JAXBException;
import java.io.IOException;


@Service
@Transactional
public class ProjectServiceImpl implements ProjectService {

    private final ProjectRepository projectRepository;

    @Autowired
    public ProjectServiceImpl(ProjectRepository projectRepository) {
        this.projectRepository = projectRepository;

    }

    @Override
    public void importProjects() throws JAXBException {
        //TODO
    }


    @Override
    public boolean areImported() {
        return this.projectRepository.count() > 0;
    }

    @Override
    public String readProjectsXmlFile() throws IOException {
        //TODO READ FILE
        return "";
    }

    @Override
    public String exportFinishedProjects() {
        //TODO
        return "";
    }


    @Override
    public void exportProjectToJson() throws IOException {
        //TODO
    }

    @Override
    public String readProjectJsonFile() throws IOException {
        //TODO READ FILE
        return "";
    }

    @Override
    public boolean areExported() throws IOException {
        return this.readProjectJsonFile().length() > 0;
    }

    @Override
    public String exportProjectsWithNameEnding() {
        //TODO
        return "";
    }
}
