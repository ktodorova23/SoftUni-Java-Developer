package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        Map<String, Integer> videosWithViews = new HashMap<>();
        Map<String, Integer> videosWithLikes = new HashMap<>();

        String input = scanner.nextLine();

        while (!input.equals("stats time")){

            if(input.contains("-")){
                String[] tokens = input.split("-");
                String video = tokens[0];
                int views = Integer.parseInt(tokens[1]);

                if(!videosWithViews.containsKey(video)){
                    videosWithViews.put(video, views);
                    videosWithLikes.put(video, 0);
                }else{
                    videosWithViews.put(video, videosWithViews.get(video) + views);
                }
            }else{
                String[] tokens = input.split(":");
                String video = tokens[1];

                if(tokens[0].equals("like")){
                    if(videosWithLikes.containsKey(video)){
                        videosWithLikes.put(video, videosWithLikes.get(video) + 1);
                    }
                }else{
                    if(videosWithLikes.containsKey(video)){
                        videosWithLikes.put(video, videosWithLikes.get(video) - 1);
                    }
                }
            }
            input = scanner.nextLine();
        }

        String sortCriteria = scanner.nextLine();

        if(sortCriteria.equals("by views")){

            videosWithViews.entrySet().stream()
                    .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                    .forEach(entry -> {
                        System.out.println(String.format(
                                "%s - %d views - %d likes"
                                ,entry.getKey(), entry.getValue(), videosWithLikes.get(entry.getKey())
                                ));
                    });

        }else{


            videosWithLikes.entrySet().stream()
                    .sorted((a, b) -> b.getValue().compareTo(a.getValue()))
                    .forEach(entry -> {
                        System.out.println(String.format(
                                "%s - %d views - %d likes"
                                ,entry.getKey(), videosWithViews.get(entry.getKey()), entry.getValue()
                        ));
                    });
        }
    }
}
