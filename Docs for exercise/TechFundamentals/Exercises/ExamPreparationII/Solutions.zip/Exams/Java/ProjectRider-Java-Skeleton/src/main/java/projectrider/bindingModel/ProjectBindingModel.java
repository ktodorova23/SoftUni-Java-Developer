package projectrider.bindingModel;

public class ProjectBindingModel {
    private String title;

    private String description;

    private Long budget;

    public ProjectBindingModel() { }

    public String getTitle() {
        return this.title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return this.description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Long getBudget() {
        return this.budget;
    }

    public void setBudget(Long budget) {
        this.budget = budget;
    }
}
