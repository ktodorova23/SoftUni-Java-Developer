<?php

/* @Twig/layout.html.twig */
class __TwigTemplate_ac4577b33a1508f28febae67b77f8b093663a6c91b13d448e6865acd42e10dd8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'head' => array($this, 'block_head'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_12fa0dbb6a53a04b1456958ae69ffc414bb605117588ba42b2de755f6d15d956 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_12fa0dbb6a53a04b1456958ae69ffc414bb605117588ba42b2de755f6d15d956->enter($__internal_12fa0dbb6a53a04b1456958ae69ffc414bb605117588ba42b2de755f6d15d956_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        $__internal_16d1ab2ceac4e486d4e6b1372655fbbfb75f963ccd0eb8aa2df858994b080eb7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16d1ab2ceac4e486d4e6b1372655fbbfb75f963ccd0eb8aa2df858994b080eb7->enter($__internal_16d1ab2ceac4e486d4e6b1372655fbbfb75f963ccd0eb8aa2df858994b080eb7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/layout.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"";
        // line 4
        echo twig_escape_filter($this->env, $this->env->getCharset(), "html", null, true);
        echo "\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>";
        // line 7
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        <link rel=\"icon\" type=\"image/png\" href=\"";
        // line 8
        echo twig_include($this->env, $context, "@Twig/images/favicon.png.base64");
        echo "\">
        <style>";
        // line 9
        echo twig_include($this->env, $context, "@Twig/exception.css.twig");
        echo "</style>
        ";
        // line 10
        $this->displayBlock('head', $context, $blocks);
        // line 11
        echo "    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">";
        // line 15
        echo twig_include($this->env, $context, "@Twig/images/symfony-logo.svg");
        echo " Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">";
        // line 19
        echo twig_include($this->env, $context, "@Twig/images/icon-book.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">";
        // line 26
        echo twig_include($this->env, $context, "@Twig/images/icon-support.svg");
        echo "</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        ";
        // line 33
        $this->displayBlock('body', $context, $blocks);
        // line 34
        echo "        ";
        echo twig_include($this->env, $context, "@Twig/base_js.html.twig");
        echo "
    </body>
</html>
";
        
        $__internal_12fa0dbb6a53a04b1456958ae69ffc414bb605117588ba42b2de755f6d15d956->leave($__internal_12fa0dbb6a53a04b1456958ae69ffc414bb605117588ba42b2de755f6d15d956_prof);

        
        $__internal_16d1ab2ceac4e486d4e6b1372655fbbfb75f963ccd0eb8aa2df858994b080eb7->leave($__internal_16d1ab2ceac4e486d4e6b1372655fbbfb75f963ccd0eb8aa2df858994b080eb7_prof);

    }

    // line 7
    public function block_title($context, array $blocks = array())
    {
        $__internal_af96a7d2197d8f00635c0c55a30868d53e9509688784d338d9b6e2057534c8ca = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_af96a7d2197d8f00635c0c55a30868d53e9509688784d338d9b6e2057534c8ca->enter($__internal_af96a7d2197d8f00635c0c55a30868d53e9509688784d338d9b6e2057534c8ca_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_5209f9c8e0f37e00d79e99b11b975393f72f8ee3a8cdb1152a92c51170241cff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5209f9c8e0f37e00d79e99b11b975393f72f8ee3a8cdb1152a92c51170241cff->enter($__internal_5209f9c8e0f37e00d79e99b11b975393f72f8ee3a8cdb1152a92c51170241cff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        
        $__internal_5209f9c8e0f37e00d79e99b11b975393f72f8ee3a8cdb1152a92c51170241cff->leave($__internal_5209f9c8e0f37e00d79e99b11b975393f72f8ee3a8cdb1152a92c51170241cff_prof);

        
        $__internal_af96a7d2197d8f00635c0c55a30868d53e9509688784d338d9b6e2057534c8ca->leave($__internal_af96a7d2197d8f00635c0c55a30868d53e9509688784d338d9b6e2057534c8ca_prof);

    }

    // line 10
    public function block_head($context, array $blocks = array())
    {
        $__internal_4cb982c1fa077b089251e1a477a4ecee0f623ae8b6a3d78b49036819e6a3077e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4cb982c1fa077b089251e1a477a4ecee0f623ae8b6a3d78b49036819e6a3077e->enter($__internal_4cb982c1fa077b089251e1a477a4ecee0f623ae8b6a3d78b49036819e6a3077e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_861e49422f694ac66807b3a0609c16999a0effb9d31142d7f77f7a761df01b37 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_861e49422f694ac66807b3a0609c16999a0effb9d31142d7f77f7a761df01b37->enter($__internal_861e49422f694ac66807b3a0609c16999a0effb9d31142d7f77f7a761df01b37_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        
        $__internal_861e49422f694ac66807b3a0609c16999a0effb9d31142d7f77f7a761df01b37->leave($__internal_861e49422f694ac66807b3a0609c16999a0effb9d31142d7f77f7a761df01b37_prof);

        
        $__internal_4cb982c1fa077b089251e1a477a4ecee0f623ae8b6a3d78b49036819e6a3077e->leave($__internal_4cb982c1fa077b089251e1a477a4ecee0f623ae8b6a3d78b49036819e6a3077e_prof);

    }

    // line 33
    public function block_body($context, array $blocks = array())
    {
        $__internal_ccca0f9e1e81cebbe82c7bd5b433ec144cb565d401d9260d126c9d01b6959aff = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ccca0f9e1e81cebbe82c7bd5b433ec144cb565d401d9260d126c9d01b6959aff->enter($__internal_ccca0f9e1e81cebbe82c7bd5b433ec144cb565d401d9260d126c9d01b6959aff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_349805c22844fdddd0812d715655bfe756f31943ed144ffa4d54c42b08edcc87 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_349805c22844fdddd0812d715655bfe756f31943ed144ffa4d54c42b08edcc87->enter($__internal_349805c22844fdddd0812d715655bfe756f31943ed144ffa4d54c42b08edcc87_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_349805c22844fdddd0812d715655bfe756f31943ed144ffa4d54c42b08edcc87->leave($__internal_349805c22844fdddd0812d715655bfe756f31943ed144ffa4d54c42b08edcc87_prof);

        
        $__internal_ccca0f9e1e81cebbe82c7bd5b433ec144cb565d401d9260d126c9d01b6959aff->leave($__internal_ccca0f9e1e81cebbe82c7bd5b433ec144cb565d401d9260d126c9d01b6959aff_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/layout.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  137 => 33,  120 => 10,  103 => 7,  88 => 34,  86 => 33,  76 => 26,  66 => 19,  59 => 15,  53 => 11,  51 => 10,  47 => 9,  43 => 8,  39 => 7,  33 => 4,  28 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"{{ _charset }}\" />
        <meta name=\"robots\" content=\"noindex,nofollow\" />
        <meta name=\"viewport\" content=\"width=device-width,initial-scale=1\" />
        <title>{% block title %}{% endblock %}</title>
        <link rel=\"icon\" type=\"image/png\" href=\"{{ include('@Twig/images/favicon.png.base64') }}\">
        <style>{{ include('@Twig/exception.css.twig') }}</style>
        {% block head %}{% endblock %}
    </head>
    <body>
        <header>
            <div class=\"container\">
                <h1 class=\"logo\">{{ include('@Twig/images/symfony-logo.svg') }} Symfony Exception</h1>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/doc\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-book.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Docs
                    </a>
                </div>

                <div class=\"help-link\">
                    <a href=\"https://symfony.com/support\">
                        <span class=\"icon\">{{ include('@Twig/images/icon-support.svg') }}</span>
                        <span class=\"hidden-xs-down\">Symfony</span> Support
                    </a>
                </div>
            </div>
        </header>

        {% block body %}{% endblock %}
        {{ include('@Twig/base_js.html.twig') }}
    </body>
</html>
", "@Twig/layout.html.twig", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\layout.html.twig");
    }
}
