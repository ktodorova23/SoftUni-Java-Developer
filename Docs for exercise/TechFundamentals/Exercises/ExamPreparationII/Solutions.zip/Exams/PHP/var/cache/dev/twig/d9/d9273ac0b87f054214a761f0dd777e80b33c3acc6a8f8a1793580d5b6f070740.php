<?php

/* @Twig/images/chevron-right.svg */
class __TwigTemplate_583a433a30e3179a35c0ffaf046b2894ef782b31cb5b56596c96b69a834ccac1 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_cf85724408f73c6f41736d56387ebb08728f837d2fb43a35997b2469a7ce4c2e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_cf85724408f73c6f41736d56387ebb08728f837d2fb43a35997b2469a7ce4c2e->enter($__internal_cf85724408f73c6f41736d56387ebb08728f837d2fb43a35997b2469a7ce4c2e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        $__internal_4972a314617cf3b73e93657ee71e16097f982282a899aadddae03a6b4eec8f6e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4972a314617cf3b73e93657ee71e16097f982282a899aadddae03a6b4eec8f6e->enter($__internal_4972a314617cf3b73e93657ee71e16097f982282a899aadddae03a6b4eec8f6e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/chevron-right.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
";
        
        $__internal_cf85724408f73c6f41736d56387ebb08728f837d2fb43a35997b2469a7ce4c2e->leave($__internal_cf85724408f73c6f41736d56387ebb08728f837d2fb43a35997b2469a7ce4c2e_prof);

        
        $__internal_4972a314617cf3b73e93657ee71e16097f982282a899aadddae03a6b4eec8f6e->leave($__internal_4972a314617cf3b73e93657ee71e16097f982282a899aadddae03a6b4eec8f6e_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/chevron-right.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path fill=\"#FFF\" d=\"M1363 877l-742 742q-19 19-45 19t-45-19l-166-166q-19-19-19-45t19-45l531-531-531-531q-19-19-19-45t19-45l166-166q19-19 45-19t45 19l742 742q19 19 19 45t-19 45z\"/></svg>
", "@Twig/images/chevron-right.svg", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\chevron-right.svg");
    }
}
