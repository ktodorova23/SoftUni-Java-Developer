<?php

/* project/create.html.twig */
class __TwigTemplate_5b28dc0b3980fc0b0375522a4945ec6c68466c5df47c7b5d35b5c50bcf7c5429 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "project/create.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_adcf4c08752f72615c9661339449b2bb16ca72b6fc471c996363877f91d9dd04 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_adcf4c08752f72615c9661339449b2bb16ca72b6fc471c996363877f91d9dd04->enter($__internal_adcf4c08752f72615c9661339449b2bb16ca72b6fc471c996363877f91d9dd04_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/create.html.twig"));

        $__internal_16ac153a14e2fbd58e8fa2df085793dafff11e8a63ec7902f7fbdd5900ceaac6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_16ac153a14e2fbd58e8fa2df085793dafff11e8a63ec7902f7fbdd5900ceaac6->enter($__internal_16ac153a14e2fbd58e8fa2df085793dafff11e8a63ec7902f7fbdd5900ceaac6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/create.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_adcf4c08752f72615c9661339449b2bb16ca72b6fc471c996363877f91d9dd04->leave($__internal_adcf4c08752f72615c9661339449b2bb16ca72b6fc471c996363877f91d9dd04_prof);

        
        $__internal_16ac153a14e2fbd58e8fa2df085793dafff11e8a63ec7902f7fbdd5900ceaac6->leave($__internal_16ac153a14e2fbd58e8fa2df085793dafff11e8a63ec7902f7fbdd5900ceaac6_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_e60103b31077fa8e01b7a50aaf7f7884c341ffbb90cb40f0017595c98fc79e1c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e60103b31077fa8e01b7a50aaf7f7884c341ffbb90cb40f0017595c98fc79e1c->enter($__internal_e60103b31077fa8e01b7a50aaf7f7884c341ffbb90cb40f0017595c98fc79e1c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_63aa1cb1ff62c72cf092603d4c59bec4543eb17d6c7ed59b6f5292ca9ae3ccf6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_63aa1cb1ff62c72cf092603d4c59bec4543eb17d6c7ed59b6f5292ca9ae3ccf6->enter($__internal_63aa1cb1ff62c72cf092603d4c59bec4543eb17d6c7ed59b6f5292ca9ae3ccf6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <form class=\"project-create\" method=\"post\">
        <div class=\"create-header\">
            Create Project
        </div>
        <div class=\"create-title\">
            <div class=\"create-title-label\">Title</div>
            <input class=\"create-title-content\" name=\"project[title]\" />
        </div>
        <div class=\"create-description\">
            <div class=\"create-description-label\">Description</div>
            <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\"></textarea>
        </div>
        <div class=\"create-budget\">
            <div class=\"create-budget-label\">Budget</div>
            <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\" />
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Create Project</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        ";
        // line 26
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
</div>
";
        
        $__internal_63aa1cb1ff62c72cf092603d4c59bec4543eb17d6c7ed59b6f5292ca9ae3ccf6->leave($__internal_63aa1cb1ff62c72cf092603d4c59bec4543eb17d6c7ed59b6f5292ca9ae3ccf6_prof);

        
        $__internal_e60103b31077fa8e01b7a50aaf7f7884c341ffbb90cb40f0017595c98fc79e1c->leave($__internal_e60103b31077fa8e01b7a50aaf7f7884c341ffbb90cb40f0017595c98fc79e1c_prof);

    }

    public function getTemplateName()
    {
        return "project/create.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  73 => 26,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <form class=\"project-create\" method=\"post\">
        <div class=\"create-header\">
            Create Project
        </div>
        <div class=\"create-title\">
            <div class=\"create-title-label\">Title</div>
            <input class=\"create-title-content\" name=\"project[title]\" />
        </div>
        <div class=\"create-description\">
            <div class=\"create-description-label\">Description</div>
            <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\"></textarea>
        </div>
        <div class=\"create-budget\">
            <div class=\"create-budget-label\">Budget</div>
            <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\" />
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Create Project</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        {{ form_row(form._token) }}
    </form>
</div>
{% endblock %}", "project/create.html.twig", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\app\\Resources\\views\\project\\create.html.twig");
    }
}
