<?php

/* @Twig/images/icon-minus-square.svg */
class __TwigTemplate_57e2c9bbaa8f3e0855fd790b90057bba5a04ddc18f08fa88680c12dc6e7b00c8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_37955b83593a611f9dd0b9c36d94bc5eb487d7b79efdb3ce97cc230c89055df0 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_37955b83593a611f9dd0b9c36d94bc5eb487d7b79efdb3ce97cc230c89055df0->enter($__internal_37955b83593a611f9dd0b9c36d94bc5eb487d7b79efdb3ce97cc230c89055df0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        $__internal_d4521b63b3144e46bd74a28551bb600cf823764cc1583bc6ddb3de03cfc71d54 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d4521b63b3144e46bd74a28551bb600cf823764cc1583bc6ddb3de03cfc71d54->enter($__internal_d4521b63b3144e46bd74a28551bb600cf823764cc1583bc6ddb3de03cfc71d54_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/images/icon-minus-square.svg"));

        // line 1
        echo "<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
";
        
        $__internal_37955b83593a611f9dd0b9c36d94bc5eb487d7b79efdb3ce97cc230c89055df0->leave($__internal_37955b83593a611f9dd0b9c36d94bc5eb487d7b79efdb3ce97cc230c89055df0_prof);

        
        $__internal_d4521b63b3144e46bd74a28551bb600cf823764cc1583bc6ddb3de03cfc71d54->leave($__internal_d4521b63b3144e46bd74a28551bb600cf823764cc1583bc6ddb3de03cfc71d54_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/images/icon-minus-square.svg";
    }

    public function getDebugInfo()
    {
        return array (  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<svg width=\"1792\" height=\"1792\" viewBox=\"0 0 1792 1792\" xmlns=\"http://www.w3.org/2000/svg\"><path d=\"M1408 960V832q0-26-19-45t-45-19H448q-26 0-45 19t-19 45v128q0 26 19 45t45 19h896q26 0 45-19t19-45zm256-544v960q0 119-84.5 203.5T1376 1664H416q-119 0-203.5-84.5T128 1376V416q0-119 84.5-203.5T416 128h960q119 0 203.5 84.5T1664 416z\"/></svg>
", "@Twig/images/icon-minus-square.svg", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\TwigBundle\\Resources\\views\\images\\icon-minus-square.svg");
    }
}
