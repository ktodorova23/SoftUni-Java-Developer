<?php

/* project/delete.html.twig */
class __TwigTemplate_a23f7e21bf4132835fec405b5350f2d203714afcff87719f4845adc93353750d extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("base.html.twig", "project/delete.html.twig", 1);
        $this->blocks = array(
            'main' => array($this, 'block_main'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_bfa383b5eb26312b200d9bff7a698758e8eee88a1776840b2531fdf8c09033d4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bfa383b5eb26312b200d9bff7a698758e8eee88a1776840b2531fdf8c09033d4->enter($__internal_bfa383b5eb26312b200d9bff7a698758e8eee88a1776840b2531fdf8c09033d4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/delete.html.twig"));

        $__internal_fcedaa935ca24decc71cedcf3c8a035e1e65215fd753ae00019943deb17085c4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_fcedaa935ca24decc71cedcf3c8a035e1e65215fd753ae00019943deb17085c4->enter($__internal_fcedaa935ca24decc71cedcf3c8a035e1e65215fd753ae00019943deb17085c4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "project/delete.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_bfa383b5eb26312b200d9bff7a698758e8eee88a1776840b2531fdf8c09033d4->leave($__internal_bfa383b5eb26312b200d9bff7a698758e8eee88a1776840b2531fdf8c09033d4_prof);

        
        $__internal_fcedaa935ca24decc71cedcf3c8a035e1e65215fd753ae00019943deb17085c4->leave($__internal_fcedaa935ca24decc71cedcf3c8a035e1e65215fd753ae00019943deb17085c4_prof);

    }

    // line 3
    public function block_main($context, array $blocks = array())
    {
        $__internal_6bf6c0a886f39ed240173a15c69fff3c11451fb5aed9c73c1a9fc62364d75a9c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bf6c0a886f39ed240173a15c69fff3c11451fb5aed9c73c1a9fc62364d75a9c->enter($__internal_6bf6c0a886f39ed240173a15c69fff3c11451fb5aed9c73c1a9fc62364d75a9c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_56c56a55645358c8b1a2d3446594e0a93939102a409d887ec0dd3696cb9e82b2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_56c56a55645358c8b1a2d3446594e0a93939102a409d887ec0dd3696cb9e82b2->enter($__internal_56c56a55645358c8b1a2d3446594e0a93939102a409d887ec0dd3696cb9e82b2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        // line 4
        echo "<div class=\"wrapper\">
    <form class=\"project-create\" method=\"post\">
        <div class=\"create-header\">
            Delete Project
        </div>
        <div class=\"create-title\">
            <div class=\"create-title-label\">Title</div>
            <input class=\"create-title-content\" name=\"project[title]\" value=\"";
        // line 11
        echo twig_escape_filter($this->env, $this->getAttribute(($context["project"] ?? $this->getContext($context, "project")), "title", array()), "html", null, true);
        echo "\" disabled=\"disabled\"/>
        </div>
        <div class=\"create-description\">
            <div class=\"create-description-label\">Description</div>
            <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\"
                      disabled=\"disabled\">";
        // line 16
        echo twig_escape_filter($this->env, $this->getAttribute(($context["project"] ?? $this->getContext($context, "project")), "description", array()), "html", null, true);
        echo "</textarea>
        </div>
        <div class=\"create-budget\">
            <div class=\"create-budget-label\">Budget</div>
            <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\" value=\"";
        // line 20
        echo twig_escape_filter($this->env, $this->getAttribute(($context["project"] ?? $this->getContext($context, "project")), "budget", array()), "html", null, true);
        echo "\"
                   disabled=\"disabled\"/>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Delete Project</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        ";
        // line 28
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Form\TwigRenderer')->searchAndRenderBlock($this->getAttribute(($context["form"] ?? $this->getContext($context, "form")), "_token", array()), 'row');
        echo "
    </form>
</div>
";
        
        $__internal_56c56a55645358c8b1a2d3446594e0a93939102a409d887ec0dd3696cb9e82b2->leave($__internal_56c56a55645358c8b1a2d3446594e0a93939102a409d887ec0dd3696cb9e82b2_prof);

        
        $__internal_6bf6c0a886f39ed240173a15c69fff3c11451fb5aed9c73c1a9fc62364d75a9c->leave($__internal_6bf6c0a886f39ed240173a15c69fff3c11451fb5aed9c73c1a9fc62364d75a9c_prof);

    }

    public function getTemplateName()
    {
        return "project/delete.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  84 => 28,  73 => 20,  66 => 16,  58 => 11,  49 => 4,  40 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"base.html.twig\" %}

{% block main %}
<div class=\"wrapper\">
    <form class=\"project-create\" method=\"post\">
        <div class=\"create-header\">
            Delete Project
        </div>
        <div class=\"create-title\">
            <div class=\"create-title-label\">Title</div>
            <input class=\"create-title-content\" name=\"project[title]\" value=\"{{ project.title }}\" disabled=\"disabled\"/>
        </div>
        <div class=\"create-description\">
            <div class=\"create-description-label\">Description</div>
            <textarea rows=\"3\" class=\"create-description-content\" name=\"project[description]\"
                      disabled=\"disabled\">{{ project.description }}</textarea>
        </div>
        <div class=\"create-budget\">
            <div class=\"create-budget-label\">Budget</div>
            <input type=\"number\" min=\"0\" class=\"create-budget-content\" name=\"project[budget]\" value=\"{{ project.budget }}\"
                   disabled=\"disabled\"/>
        </div>
        <div class=\"create-button-holder\">
            <button type=\"submit\" class=\"submit-button\">Delete Project</button>
            <a type=\"button\" href=\"/\" class=\"back-button\">Back</a>
        </div>

        {{ form_row(form._token) }}
    </form>
</div>
{% endblock %}", "project/delete.html.twig", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\app\\Resources\\views\\project\\delete.html.twig");
    }
}
