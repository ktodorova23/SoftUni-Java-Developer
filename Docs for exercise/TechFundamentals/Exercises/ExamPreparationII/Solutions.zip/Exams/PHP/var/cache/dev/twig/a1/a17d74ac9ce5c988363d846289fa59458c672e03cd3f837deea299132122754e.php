<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_0acfe6e0d74ca654a1a4affc281db3f3a85b89e0dc74c98b09bfaf6fb7b9bf4c extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_b682dc2ed86106a8b81f3a7c69de822b84ddede878900da0724e07d9d10e84c9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b682dc2ed86106a8b81f3a7c69de822b84ddede878900da0724e07d9d10e84c9->enter($__internal_b682dc2ed86106a8b81f3a7c69de822b84ddede878900da0724e07d9d10e84c9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_12d65e1c0f7ad91fd31ac5876693ef2592fe9373c99b2fca57529bb8fade0dd6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12d65e1c0f7ad91fd31ac5876693ef2592fe9373c99b2fca57529bb8fade0dd6->enter($__internal_12d65e1c0f7ad91fd31ac5876693ef2592fe9373c99b2fca57529bb8fade0dd6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_b682dc2ed86106a8b81f3a7c69de822b84ddede878900da0724e07d9d10e84c9->leave($__internal_b682dc2ed86106a8b81f3a7c69de822b84ddede878900da0724e07d9d10e84c9_prof);

        
        $__internal_12d65e1c0f7ad91fd31ac5876693ef2592fe9373c99b2fca57529bb8fade0dd6->leave($__internal_12d65e1c0f7ad91fd31ac5876693ef2592fe9373c99b2fca57529bb8fade0dd6_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_217a92ddfaec58cea9a6c4e8f211c3e2cb30ae447b90fe44cf45cc5041cd878b = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_217a92ddfaec58cea9a6c4e8f211c3e2cb30ae447b90fe44cf45cc5041cd878b->enter($__internal_217a92ddfaec58cea9a6c4e8f211c3e2cb30ae447b90fe44cf45cc5041cd878b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_817287e5d00e21536c23331fbd5732ddbabd37f2a68e0879dc31d921ea78718d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_817287e5d00e21536c23331fbd5732ddbabd37f2a68e0879dc31d921ea78718d->enter($__internal_817287e5d00e21536c23331fbd5732ddbabd37f2a68e0879dc31d921ea78718d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_817287e5d00e21536c23331fbd5732ddbabd37f2a68e0879dc31d921ea78718d->leave($__internal_817287e5d00e21536c23331fbd5732ddbabd37f2a68e0879dc31d921ea78718d_prof);

        
        $__internal_217a92ddfaec58cea9a6c4e8f211c3e2cb30ae447b90fe44cf45cc5041cd878b->leave($__internal_217a92ddfaec58cea9a6c4e8f211c3e2cb30ae447b90fe44cf45cc5041cd878b_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_a7f099d625e300a9f15b41f656e9de365623c3b1f37149590017c40e2865b7b8 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a7f099d625e300a9f15b41f656e9de365623c3b1f37149590017c40e2865b7b8->enter($__internal_a7f099d625e300a9f15b41f656e9de365623c3b1f37149590017c40e2865b7b8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_2b3fbf35649478181567eb411f7e9cf142b764785912b440d8a60d43d4d62997 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2b3fbf35649478181567eb411f7e9cf142b764785912b440d8a60d43d4d62997->enter($__internal_2b3fbf35649478181567eb411f7e9cf142b764785912b440d8a60d43d4d62997_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_2b3fbf35649478181567eb411f7e9cf142b764785912b440d8a60d43d4d62997->leave($__internal_2b3fbf35649478181567eb411f7e9cf142b764785912b440d8a60d43d4d62997_prof);

        
        $__internal_a7f099d625e300a9f15b41f656e9de365623c3b1f37149590017c40e2865b7b8->leave($__internal_a7f099d625e300a9f15b41f656e9de365623c3b1f37149590017c40e2865b7b8_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_f0dfd3de2deca08f65fed245996a7f85b3058bc926171de016a3e7f57be034a6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f0dfd3de2deca08f65fed245996a7f85b3058bc926171de016a3e7f57be034a6->enter($__internal_f0dfd3de2deca08f65fed245996a7f85b3058bc926171de016a3e7f57be034a6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_f47b128e58a895f2de4edbd0d976427f559eb31d3845601174537dcd6f390af7 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f47b128e58a895f2de4edbd0d976427f559eb31d3845601174537dcd6f390af7->enter($__internal_f47b128e58a895f2de4edbd0d976427f559eb31d3845601174537dcd6f390af7_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_f47b128e58a895f2de4edbd0d976427f559eb31d3845601174537dcd6f390af7->leave($__internal_f47b128e58a895f2de4edbd0d976427f559eb31d3845601174537dcd6f390af7_prof);

        
        $__internal_f0dfd3de2deca08f65fed245996a7f85b3058bc926171de016a3e7f57be034a6->leave($__internal_f0dfd3de2deca08f65fed245996a7f85b3058bc926171de016a3e7f57be034a6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
