<?php

/* base.html.twig */
class __TwigTemplate_a17f9d7aa975e34f4e0cc44eeab7f33089147d69ffdc6090114c99e26dfbd157 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1e5623163646ec50aeb56898073ee3883a7cb6e056b619411a69a1ba37f3fea5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e5623163646ec50aeb56898073ee3883a7cb6e056b619411a69a1ba37f3fea5->enter($__internal_1e5623163646ec50aeb56898073ee3883a7cb6e056b619411a69a1ba37f3fea5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_81c36c7945cf34f0998395d9abb9b224bbea084cf52e83f2d817e879c0e50f64 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_81c36c7945cf34f0998395d9abb9b224bbea084cf52e83f2d817e879c0e50f64->enter($__internal_81c36c7945cf34f0998395d9abb9b224bbea084cf52e83f2d817e879c0e50f64_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <title>";
        // line 10
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 11
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">
";
        // line 20
        $this->displayBlock('body', $context, $blocks);
        // line 23
        echo "</body>
</html>
";
        
        $__internal_1e5623163646ec50aeb56898073ee3883a7cb6e056b619411a69a1ba37f3fea5->leave($__internal_1e5623163646ec50aeb56898073ee3883a7cb6e056b619411a69a1ba37f3fea5_prof);

        
        $__internal_81c36c7945cf34f0998395d9abb9b224bbea084cf52e83f2d817e879c0e50f64->leave($__internal_81c36c7945cf34f0998395d9abb9b224bbea084cf52e83f2d817e879c0e50f64_prof);

    }

    // line 10
    public function block_title($context, array $blocks = array())
    {
        $__internal_1e4cb9051a8780b69c4e1c1cf672cd2a11c8842d063e38e5ece29587398a6695 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1e4cb9051a8780b69c4e1c1cf672cd2a11c8842d063e38e5ece29587398a6695->enter($__internal_1e4cb9051a8780b69c4e1c1cf672cd2a11c8842d063e38e5ece29587398a6695_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_e12f9061c9eb1fe782bd4b444cd1bbd71e801ad06ed410fa5849764c944e7ef0 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_e12f9061c9eb1fe782bd4b444cd1bbd71e801ad06ed410fa5849764c944e7ef0->enter($__internal_e12f9061c9eb1fe782bd4b444cd1bbd71e801ad06ed410fa5849764c944e7ef0_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Project Rider";
        
        $__internal_e12f9061c9eb1fe782bd4b444cd1bbd71e801ad06ed410fa5849764c944e7ef0->leave($__internal_e12f9061c9eb1fe782bd4b444cd1bbd71e801ad06ed410fa5849764c944e7ef0_prof);

        
        $__internal_1e4cb9051a8780b69c4e1c1cf672cd2a11c8842d063e38e5ece29587398a6695->leave($__internal_1e4cb9051a8780b69c4e1c1cf672cd2a11c8842d063e38e5ece29587398a6695_prof);

    }

    // line 11
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_1612117f3028e887d38c04690fd5bf9de0494d1f47a664cfb36428c06ca1ce1f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1612117f3028e887d38c04690fd5bf9de0494d1f47a664cfb36428c06ca1ce1f->enter($__internal_1612117f3028e887d38c04690fd5bf9de0494d1f47a664cfb36428c06ca1ce1f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_161f931e3a6def8415a8d29aedd30ef67a417697fdf134cdc9e30773c677a5de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_161f931e3a6def8415a8d29aedd30ef67a417697fdf134cdc9e30773c677a5de->enter($__internal_161f931e3a6def8415a8d29aedd30ef67a417697fdf134cdc9e30773c677a5de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 12
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/reset.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 13
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/create-style.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_161f931e3a6def8415a8d29aedd30ef67a417697fdf134cdc9e30773c677a5de->leave($__internal_161f931e3a6def8415a8d29aedd30ef67a417697fdf134cdc9e30773c677a5de_prof);

        
        $__internal_1612117f3028e887d38c04690fd5bf9de0494d1f47a664cfb36428c06ca1ce1f->leave($__internal_1612117f3028e887d38c04690fd5bf9de0494d1f47a664cfb36428c06ca1ce1f_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_06db45d9718891110ba713a30ab7676e62ad87ebb28ce90416e9a26963c35e89 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_06db45d9718891110ba713a30ab7676e62ad87ebb28ce90416e9a26963c35e89->enter($__internal_06db45d9718891110ba713a30ab7676e62ad87ebb28ce90416e9a26963c35e89_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_8c5a0dc2c5e041059147f9afe9e2ef6c82d3568042068b44c7991a2ec71704de = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8c5a0dc2c5e041059147f9afe9e2ef6c82d3568042068b44c7991a2ec71704de->enter($__internal_8c5a0dc2c5e041059147f9afe9e2ef6c82d3568042068b44c7991a2ec71704de_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_8c5a0dc2c5e041059147f9afe9e2ef6c82d3568042068b44c7991a2ec71704de->leave($__internal_8c5a0dc2c5e041059147f9afe9e2ef6c82d3568042068b44c7991a2ec71704de_prof);

        
        $__internal_06db45d9718891110ba713a30ab7676e62ad87ebb28ce90416e9a26963c35e89->leave($__internal_06db45d9718891110ba713a30ab7676e62ad87ebb28ce90416e9a26963c35e89_prof);

    }

    // line 20
    public function block_body($context, array $blocks = array())
    {
        $__internal_f672791cec0e0e9f4db9ca6d8b2932eae2dca57dbe905793f43e950884d4619f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_f672791cec0e0e9f4db9ca6d8b2932eae2dca57dbe905793f43e950884d4619f->enter($__internal_f672791cec0e0e9f4db9ca6d8b2932eae2dca57dbe905793f43e950884d4619f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_4cb18a985c262e5c2a59dd98041d58dce72516f7e6f2773241cd9acc3cca0da5 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_4cb18a985c262e5c2a59dd98041d58dce72516f7e6f2773241cd9acc3cca0da5->enter($__internal_4cb18a985c262e5c2a59dd98041d58dce72516f7e6f2773241cd9acc3cca0da5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 21
        echo "    ";
        $this->displayBlock('main', $context, $blocks);
        
        $__internal_4cb18a985c262e5c2a59dd98041d58dce72516f7e6f2773241cd9acc3cca0da5->leave($__internal_4cb18a985c262e5c2a59dd98041d58dce72516f7e6f2773241cd9acc3cca0da5_prof);

        
        $__internal_f672791cec0e0e9f4db9ca6d8b2932eae2dca57dbe905793f43e950884d4619f->leave($__internal_f672791cec0e0e9f4db9ca6d8b2932eae2dca57dbe905793f43e950884d4619f_prof);

    }

    public function block_main($context, array $blocks = array())
    {
        $__internal_6bc4bec50626afcf49c17df3ef3c3284de10be5ea9175dc01f3a58cfa30c8923 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6bc4bec50626afcf49c17df3ef3c3284de10be5ea9175dc01f3a58cfa30c8923->enter($__internal_6bc4bec50626afcf49c17df3ef3c3284de10be5ea9175dc01f3a58cfa30c8923_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_d21b2e2f7d75be127e8a7c628759f3ba14713f8ed880004162244c1852458c5c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_d21b2e2f7d75be127e8a7c628759f3ba14713f8ed880004162244c1852458c5c->enter($__internal_d21b2e2f7d75be127e8a7c628759f3ba14713f8ed880004162244c1852458c5c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_d21b2e2f7d75be127e8a7c628759f3ba14713f8ed880004162244c1852458c5c->leave($__internal_d21b2e2f7d75be127e8a7c628759f3ba14713f8ed880004162244c1852458c5c_prof);

        
        $__internal_6bc4bec50626afcf49c17df3ef3c3284de10be5ea9175dc01f3a58cfa30c8923->leave($__internal_6bc4bec50626afcf49c17df3ef3c3284de10be5ea9175dc01f3a58cfa30c8923_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  141 => 21,  132 => 20,  115 => 19,  103 => 14,  99 => 13,  94 => 12,  85 => 11,  67 => 10,  55 => 23,  53 => 20,  49 => 19,  42 => 16,  40 => 11,  36 => 10,  30 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <title>{% block title %}Project Rider{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/reset.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/create-style.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">
{% block body %}
    {% block main %}{% endblock %}
{% endblock %}
</body>
</html>
", "base.html.twig", "C:\\Users\\atriu\\Desktop\\Exam\\PHP\\PHP-Skeleton\\app\\Resources\\views\\base.html.twig");
    }
}
