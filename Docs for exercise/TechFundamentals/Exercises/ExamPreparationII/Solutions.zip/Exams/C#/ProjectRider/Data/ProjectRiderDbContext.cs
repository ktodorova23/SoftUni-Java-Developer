﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using ProjectRider.Models;

namespace ProjectRider.Data
{
    public class ProjectRiderDbContext : DbContext
    {
        public DbSet<Project> Projects { get; set; }

        public ProjectRiderDbContext()
        {
            
        }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer("Server=.\\SQLEXPRESS;Database=ProjectRiderDb;Integrated Security=true");

            base.OnConfiguring(optionsBuilder);
        }

        
    }
}
