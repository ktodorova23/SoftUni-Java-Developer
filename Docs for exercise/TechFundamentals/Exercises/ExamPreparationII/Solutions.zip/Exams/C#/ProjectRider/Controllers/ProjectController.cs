﻿using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProjectRider.Data;
using ProjectRider.Models;

namespace ProjectRider.Controllers
{
    public class ProjectController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            using (var context = new ProjectRiderDbContext())
            {
                return this.View(context.Projects.ToList());
            }
        }

        [HttpGet]
        public ActionResult Create()
        {
            return this.View();
        }

        [HttpPost]
        public ActionResult Create(Project project)
        {
            using (var context = new ProjectRiderDbContext())
            {
                context.Projects.Add(project);

                context.SaveChanges();

                return this.RedirectToAction("Index");
            }
        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            using (var context = new ProjectRiderDbContext())
            {
                Project projectFromDb = context
                    .Projects
                    .FirstOrDefault(p => p.Id == id);

                return this.View(projectFromDb);
            }
        }

        [HttpPost]
        public ActionResult Edit(Project projectModel)
        {
            using (var context = new ProjectRiderDbContext())
            {
                Project projectFromDb = context
                    .Projects
                    .FirstOrDefault(x => x.Id == projectModel.Id);

                projectFromDb.Title = projectModel.Title;
                projectFromDb.Description = projectModel.Description;
                projectFromDb.Budget = projectModel.Budget;

                context.SaveChanges();
            }

            return this.RedirectToAction("Index");
        }

        [HttpGet]
        public ActionResult Delete(int id)
        {
            using (var context = new ProjectRiderDbContext())
            {
                Project projectFromDb = context
                    .Projects
                    .FirstOrDefault(p => p.Id == id);

                return this.View(projectFromDb);
            }
        }

        [HttpPost]
        public ActionResult Delete(Project projectModel)
        {
            using (var context = new ProjectRiderDbContext())
            {
                context.Remove(projectModel);

                context.SaveChanges();
            }

            return this.RedirectToAction("Index");
        }
    }
}